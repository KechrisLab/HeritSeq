## Test environments
* ??? 
* ???
* ???

## R CMD check results
There were no ERRORs or WARNINGs. 

There was 1 NOTE:

* checking CRAN incoming feasibility ... NOTE
Maintainer: ‘Jane Doe <Jane.Doe@ucdenver.edu>’
New submission

This is Jane Doe's first submission to CRAN.

## Downstream dependencies
There are currently no downstream dependencies for this package.


